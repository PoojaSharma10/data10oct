package com.flp.ems.dao;

import java.sql.SQLException;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {
	public void addEmployee(Employee employee) throws SQLException;
	   
    public boolean modifyEmployee(int id,Employee emp) throws SQLException;
   
    public void removeEmployee(int employeeid)throws SQLException;
  
    
    public boolean searchEmployee(int id) throws SQLException;
   
    public void showAllEmployee() throws SQLException;
}
