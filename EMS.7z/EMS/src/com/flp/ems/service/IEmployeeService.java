package com.flp.ems.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.flp.ems.domain.Employee;

public interface IEmployeeService {
	public void addEmployee(HashMap<String, Object> hashmap) throws SQLException;
   
    public boolean modifyEmployee(int id,HashMap<String,Object> hashmap) throws CloneNotSupportedException, SQLException;
   
    public void removeEmployee(int id)throws SQLException;
  
    
    public boolean searchEmployee(int id) throws SQLException;
   
    public void showAllEmployee() throws SQLException;
    
}
